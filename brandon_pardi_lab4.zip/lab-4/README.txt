LAB 4

ensure in proper directory corresponding to each question

Q1
compile: g++ pointers.cpp -o pointers.out
run: ./pointers.out

Q2
compile: g++ references.cpp -o references.out
run ./references.out

Q3
compile: g++ proxy.cpp -o proxy.out
run ./proxy.out